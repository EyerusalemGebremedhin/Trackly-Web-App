"use client";

import { useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, Users, Sparkles } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import HeroIllustration from "@/components/HeroIllustration";
import ThemeToggle from "@/components/ThemeToggle";

const FEATURES = [
  {
    icon: CheckCircle2,
    title: "Track your own progress",
    body: "Daily or weekly check-ins: what you aimed for, what got done, what's in the way. Your own honest record, kept over time.",
  },
  {
    icon: Users,
    title: "Lead a team with clarity",
    body: "See everyone's progress against a shared goal, who's blocked, and who's carrying too much, without chasing status updates.",
  },
  {
    icon: Sparkles,
    title: "AI that reads the details",
    body: "Not just done or not done. The analyzer weighs blockers and workload before judging, so it's a fair review, not a guess.",
  },
];

export default function LandingPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && user) router.push("/dashboard");
  }, [loading, user, router]);

  return (
    <div className="min-h-screen bg-paper">
      {/* Nav */}
      <header className="flex items-center justify-between px-6 md:px-12 py-5 max-w-6xl mx-auto">
        <span className="font-serif text-2xl text-primary">Trackly</span>
        <nav className="flex items-center gap-3">
          <ThemeToggle />
          <Link href="/login" className="text-sm text-ink hover:text-primary px-3 py-2">
            Log in
          </Link>
          <Link
            href="/signup"
            className="text-sm bg-primary hover:bg-primary-hover text-white rounded-md px-4 py-2 font-medium transition-colors"
          >
            Get started free
          </Link>
        </nav>
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 md:px-12 py-12 md:py-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="font-serif text-4xl md:text-5xl text-ink leading-tight">
            Progress, <span className="text-primary">tracked honestly.</span>
          </h1>
          <p className="text-base text-muted mt-5 max-w-md">
            Whether it's just you, or a team you lead, check in on what you actually did, what's
            blocking you, and let the honest record speak for itself.
          </p>
          <div className="flex items-center gap-3 mt-8">
            <Link
              href="/signup"
              className="bg-primary hover:bg-primary-hover text-white rounded-md px-5 py-2.5 text-sm font-medium transition-colors"
            >
              Get started free
            </Link>
            <Link href="/login" className="text-sm text-ink border border-hairline rounded-md px-5 py-2.5 hover:border-primary">
              Log in
            </Link>
          </div>
        </div>
        <HeroIllustration />
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 md:px-12 py-12 grid md:grid-cols-3 gap-6">
        {FEATURES.map(({ icon: Icon, title, body }) => (
          <div key={title} className="bg-surface border border-hairline rounded-md p-5">
            <Icon size={22} className="text-primary mb-3" />
            <h3 className="font-serif text-lg text-accent mb-1.5">{title}</h3>
            <p className="text-sm text-muted">{body}</p>
          </div>
        ))}
      </section>

      {/* Quote */}
      <section className="max-w-3xl mx-auto px-6 md:px-12 py-16 text-center">
        <p className="font-serif text-2xl md:text-3xl text-ink leading-snug">
          "What gets checked in, gets seen. What gets seen, gets fair credit."
        </p>
        <p className="text-sm text-muted mt-4">The idea behind Trackly.</p>
      </section>

      <footer className="border-t border-hairline">
        <div className="max-w-6xl mx-auto px-6 md:px-12 py-6 flex items-center justify-between text-xs text-muted">
          <span>Trackly</span>
          <span>Progress, tracked honestly.</span>
        </div>
      </footer>
    </div>
  );
}
